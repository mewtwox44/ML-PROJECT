"""Generates the graphs in ./graphs. Run: python make_graphs.py  (needs matplotlib, numpy)
Per-email scores come from the same keyword logic used in MailSorter.html."""
import json, os
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

here = os.path.dirname(os.path.abspath(__file__))
out = os.path.join(here, "graphs"); os.makedirs(out, exist_ok=True)
res = json.load(open(os.path.join(here, "demo_scores.json")))
TEAL, RED, INK = "#0e7c7b", "#b3261e", "#12263a"
plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False})

# 1. Spam probability per demo email
labels = ["1 Prize\nwinner", "2 Library\nhours", "3 Verify\npassword", "4 Quiz\nteam won", "5 Account\nscam"]
x = np.arange(len(res)); w = 0.36
fig, ax = plt.subplots(figsize=(9, 5))
ax.bar(x - w/2, [r["dt"]*100 for r in res], w, label="Decision Tree", color="#7aa6c2")
ax.bar(x + w/2, [r["xg"]*100 for r in res], w, label="XGBoost", color=TEAL)
ax.axhline(50, color=RED, ls="--", lw=1.2); ax.text(len(res)-0.5, 52, "50% spam threshold", color=RED, ha="right", fontsize=9)
for i, r in enumerate(res):
    ax.text(i - w/2, r["dt"]*100 + 1.5, f'{r["dt"]*100:.0f}%', ha="center", fontsize=9)
    ax.text(i + w/2, r["xg"]*100 + 1.5, f'{r["xg"]*100:.0f}%', ha="center", fontsize=9)
ax.set_xticks(x); ax.set_xticklabels(labels); ax.set_ylim(0, 112)
ax.set_ylabel("Spam probability (%)"); ax.set_title("Spam probability for the five demo emails", color=INK, weight="bold")
ax.legend(frameon=False, loc="upper center", ncol=2); fig.tight_layout(); fig.savefig(f"{out}/1_demo_email_scores.png", dpi=160); plt.close(fig)

# 2. Verdict agreement grid
fig, ax = plt.subplots(figsize=(7, 3.6))
for i, r in enumerate(res):
    for j, k in enumerate(("dts", "xgs")):
        ax.add_patch(plt.Rectangle((j, len(res)-1-i), 0.95, 0.9, color=RED if r[k] else TEAL, alpha=.85))
        ax.text(j+.475, len(res)-1-i+.45, "Spam" if r[k] else "Legit", ha="center", va="center", color="white", weight="bold")
ax.set_xlim(0, 2); ax.set_ylim(0, len(res)); ax.set_xticks([.475, 1.475]); ax.set_xticklabels(["Decision Tree", "XGBoost"])
ax.set_yticks([len(res)-1-i+.45 for i in range(len(res))]); ax.set_yticklabels([l.replace("\n", " ") for l in labels])
ax.tick_params(length=0)
for s in ax.spines.values(): s.set_visible(False)
ax.set_title("Verdict per model (rows 3 and 4 disagree)", color=INK, weight="bold")
fig.tight_layout(); fig.savefig(f"{out}/2_verdict_grid.png", dpi=160); plt.close(fig)

# 3. Test-set metrics (from the notebook, as shown on the Model results tab)
m = ["Accuracy", "Precision", "Recall", "F1", "CV accuracy", "CV F1"]
dt = [98.70, 98.28, 99.40, 98.84, 98.37, 98.54]; xg = [99.14, 98.82, 99.66, 99.24, 99.05, 99.15]
x = np.arange(len(m)); fig, ax = plt.subplots(figsize=(9, 5))
ax.bar(x - w/2, dt, w, label="Decision Tree", color="#7aa6c2"); ax.bar(x + w/2, xg, w, label="XGBoost", color=TEAL)
for i in range(len(m)):
    ax.text(i - w/2, dt[i] + .03, f"{dt[i]:.2f}", ha="center", fontsize=8); ax.text(i + w/2, xg[i] + .03, f"{xg[i]:.2f}", ha="center", fontsize=8)
ax.set_ylim(97.5, 100); ax.set_xticks(x); ax.set_xticklabels(m); ax.set_ylabel("%")
ax.set_title("Decision Tree vs XGBoost: notebook metrics (y-axis starts at 97.5%)", color=INK, weight="bold")
ax.legend(frameon=False, loc="upper left"); fig.tight_layout(); fig.savefig(f"{out}/3_model_metrics.png", dpi=160); plt.close(fig)

# 4. Approximate confusion matrices (reconstructed from precision, recall and class sizes)
cms = {"Decision Tree": [[3386, 76], [26, 4343]], "XGBoost": [[3410, 52], [15, 4354]]}
fig, axs = plt.subplots(1, 2, figsize=(9, 4))
for ax, (name, cm) in zip(axs, cms.items()):
    ax.imshow(cm, cmap="Blues")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, f"{cm[i][j]:,}", ha="center", va="center", weight="bold", color="white" if cm[i][j] > 2000 else INK)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["Pred. legit", "Pred. spam"]); ax.set_yticks([0, 1]); ax.set_yticklabels(["Legit", "Spam"])
    ax.set_title(name, color=INK, weight="bold")
    for s in ax.spines.values(): s.set_visible(False)
fig.suptitle("Confusion matrices (approximate, 7,831 test emails)", color=INK, weight="bold"); fig.tight_layout()
fig.savefig(f"{out}/4_confusion_matrices.png", dpi=160); plt.close(fig)

# 5. Class balance
fig, ax = plt.subplots(figsize=(7, 2.6))
ax.barh([0], [17312], color=TEAL); ax.barh([0], [21842], left=[17312], color=RED)
ax.text(17312/2, 0, "Legit 17,312 (44.2%)", ha="center", va="center", color="white", weight="bold")
ax.text(17312+21842/2, 0, "Spam 21,842 (55.8%)", ha="center", va="center", color="white", weight="bold")
ax.axis("off"); ax.set_title("CEAS-08 class balance (39,154 emails)", color=INK, weight="bold")
fig.tight_layout(); fig.savefig(f"{out}/5_class_balance.png", dpi=160); plt.close(fig)
print("done")
