MailSorter project
- MailSorter.html   : the web app (open in any browser; sign in with any email/password)
- make_graphs.py    : regenerates the graphs (python make_graphs.py; needs matplotlib, numpy)
- demo_scores.json  : scores of the five demo emails from the page's keyword models
- graphs/           : PNG charts
Note: the page uses keyword stand-ins, not the trained models. Graphs 3-4 use notebook metrics.
